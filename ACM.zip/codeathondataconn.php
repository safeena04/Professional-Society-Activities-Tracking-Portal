<?php 
$con=mysqli_connect("localhost","root","","events"); 
if(!$con) { die(" Connection Error "); } 
?>