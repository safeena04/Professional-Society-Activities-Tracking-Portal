<?php 
$con=mysqli_connect("localhost","root","","feedback"); 
if(!$con) { die(" Connection Error "); } 
?>